const base = require('@playwright/test');
const { AuthPage } = require('../pages/AuthPage');
const { SearchPage } = require('../pages/SearchPage');
const { CartPage } = require('../pages/CartPage');
const { CheckoutPage } = require('../pages/CheckoutPage');
const { AccountPage } = require('../pages/AccountPage');
const { newUser, BASE_URL } = require('../test-data/data');

// The worker fixture below creates its own browser context, so set the test id
// attribute here as well (the config only applies it to the normal test pages).
base.selectors.setTestIdAttribute('data-test');

const test = base.test.extend({
  /**
   * A brand-new customer, registered once per worker.
   * The shared demo account on the public site gets locked or changed by other
   * visitors, so the tests never depend on it.
   */
  account: [
    async ({ browser }, use) => {
      const context = await browser.newContext({ baseURL: BASE_URL });
      const page = await context.newPage();
      const user = newUser();
      await new AuthPage(page).signUp(user);
      await base.expect(page).toHaveURL(/auth\/login/, { timeout: 60_000 });
      await context.close();
      await use({ ...user, fullName: `${user.firstName} ${user.lastName}` });
    },
    { scope: 'worker', timeout: 180_000 },
  ],

  authPage: async ({ page }, use) => use(new AuthPage(page)),
  searchPage: async ({ page }, use) => use(new SearchPage(page)),
  cartPage: async ({ page }, use) => use(new CartPage(page)),
  checkoutPage: async ({ page }, use) => use(new CheckoutPage(page)),
  accountPage: async ({ page }, use) => use(new AccountPage(page)),

  // A page where the test customer is already logged in
  loggedInPage: async ({ page, authPage, account }, use) => {
    await authPage.login(account.email, account.password);
    await base.expect(authPage.navMenu).toBeVisible();
    await use(page);
  },
});

module.exports = { test, expect: base.expect };
