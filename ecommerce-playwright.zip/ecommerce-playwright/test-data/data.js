const uniqueEmail = (prefix = 'user') =>
  `${prefix}+${Date.now()}${Math.floor(Math.random() * 1000)}@example.com`;

const randomDigits = (n) =>
  Array.from({ length: n }, () => Math.floor(Math.random() * 10)).join('');

module.exports = {
  BASE_URL: process.env.BASE_URL || 'https://practicesoftwaretesting.com',

  // A brand-new customer for every call (sign up needs a unique email)
  newUser: () => ({
    firstName: 'Test',
    lastName: 'User',
    dob: '1990-05-15',
    country: 'US',
    postalCode: '12345',
    houseNumber: '12',
    street: 'Main Street',
    city: 'Springfield',
    state: 'Illinois',
    phone: `06${randomDigits(8)}`,
    email: uniqueEmail('signup'),
    password: 'Str0ng!Passw0rd',
  }),

  address: {
    postalCode: '12345',
    houseNumber: '12',
    street: 'Main Street',
    city: 'Springfield',
    state: 'Illinois',
  },

  // Toolshop's payment form accepts these formats - never use real card data
  card: {
    valid: {
      number: '1111-1111-1111-1111',
      expiry: '12/2030',
      cvv: '123',
      name: 'Jane Doe',
    },
    invalidNumber: '1234',
  },

  products: {
    searchTerm: 'hammer',
    unknownTerm: 'zzzxxyyqq',
  },

  randomDigits,
  uniqueEmail,
};
