const { expect } = require('@playwright/test');
const { products, address } = require('../test-data/data');

/**
 * Places a cash-on-delivery order for the first search result.
 * The user must already be logged in.
 */
async function placeCashOnDeliveryOrder({ searchPage, cartPage, checkoutPage }) {
  await searchPage.search(products.searchTerm);
  await expect(searchPage.productCards.first()).toBeVisible();
  await searchPage.openProduct(0);
  await cartPage.addCurrentProduct();
  await cartPage.open();

  await checkoutPage.goToAddressStep();
  await checkoutPage.fillAddress(address);
  await checkoutPage.goToPaymentStep();
  await checkoutPage.paymentMethod.selectOption('cash-on-delivery');
  await checkoutPage.confirmPayment();
  await expect(checkoutPage.orderConfirmation).toBeVisible();
}

module.exports = { placeCashOnDeliveryOrder };
