const { test, expect } = require('../fixtures');
const { products, randomDigits } = require('../test-data/data');
const { placeCashOnDeliveryOrder } = require('../helpers/order');

test.describe('Account', () => {
  test('updates the profile', async ({ loggedInPage, accountPage }) => {
    // Only the phone number changes, so the name shown in the header stays the same
    const phone = `06${randomDigits(8)}`;
    await accountPage.updatePhone(phone);
    await expect(accountPage.successAlert).toBeVisible();

    await accountPage.openProfile();
    await expect(accountPage.phone).toHaveValue(phone);
  });

  test('shows order history after an order', async ({
    loggedInPage,
    accountPage,
    searchPage,
    cartPage,
    checkoutPage,
  }) => {
    // A new customer has no orders yet, so place one first
    await placeCashOnDeliveryOrder({ searchPage, cartPage, checkoutPage });

    await accountPage.openInvoices();
    await expect(accountPage.invoiceRows.first()).toBeVisible();
    await expect(accountPage.invoiceRows.first()).toContainText(/INV-/i);
  });

  test('adds and removes a wishlist (favorites) item', async ({
    loggedInPage,
    accountPage,
    searchPage,
  }) => {
    await accountPage.clearFavorites();

    await searchPage.search(products.searchTerm);
    await expect(searchPage.productCards.first()).toBeVisible();
    await searchPage.openProduct(0);
    const name = ((await accountPage.page.getByTestId('product-name').textContent()) || '').trim();

    const saved = accountPage.page.waitForResponse(
      (r) => r.url().includes('favorites') && r.request().method() === 'POST',
    );
    await accountPage.addToFavorites.click();
    expect((await saved).ok()).toBeTruthy();

    await accountPage.openFavorites();
    await expect(accountPage.favoriteCards).toHaveCount(1);
    await expect(accountPage.favoriteCards.first()).toContainText(name);

    await accountPage.deleteFavoriteButtons.first().click();
    await expect(accountPage.favoriteCards).toHaveCount(0);
  });
});
