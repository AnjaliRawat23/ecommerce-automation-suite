const { test, expect } = require('../fixtures');
const { products } = require('../test-data/data');

async function addFirstProduct(searchPage, cartPage) {
  await searchPage.search(products.searchTerm);
  await expect(searchPage.productCards.first()).toBeVisible();
  await searchPage.openProduct(0);
  await cartPage.addCurrentProduct();
}

test.describe('Shopping cart', () => {
  test('adds an item to the cart', async ({ searchPage, cartPage }) => {
    await addFirstProduct(searchPage, cartPage);
    await expect(cartPage.cartBadge).toHaveText('1');

    await cartPage.open();
    await expect(cartPage.rows).toHaveCount(1);
  });

  test('removes an item from the cart', async ({ searchPage, cartPage }) => {
    await addFirstProduct(searchPage, cartPage);
    await cartPage.open();
    await expect(cartPage.rows).toHaveCount(1);

    await cartPage.removeRow(0);
    await expect(cartPage.rows).toHaveCount(0);
  });

  test('changing quantity updates the line total', async ({ searchPage, cartPage }) => {
    await addFirstProduct(searchPage, cartPage);
    await cartPage.open();
    await expect(cartPage.rows).toHaveCount(1);
    const unit = await cartPage.unitPriceOf(0);

    await cartPage.setQuantity(0, 3);
    await expect.poll(() => cartPage.lineTotalOf(0)).toBeCloseTo(unit * 3, 1);
    await expect.poll(() => cartPage.quantityOf(0)).toBe(3);
  });

  test('cart is kept after login', async ({ searchPage, cartPage, authPage, account }) => {
    // add as a guest, then log in
    await addFirstProduct(searchPage, cartPage);
    await authPage.login(account.email, account.password);
    await expect(authPage.navMenu).toBeVisible();

    await cartPage.open();
    await expect(cartPage.rows.first()).toBeVisible();
  });
});
