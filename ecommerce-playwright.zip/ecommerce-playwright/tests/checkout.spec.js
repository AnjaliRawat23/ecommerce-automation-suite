const { test, expect } = require('../fixtures');
const { products, address, card } = require('../test-data/data');

test.describe('Checkout', () => {
  // Every test starts logged in with one product in the cart, on the address step
  test.beforeEach(async ({ loggedInPage, searchPage, cartPage, checkoutPage }) => {
    await searchPage.search(products.searchTerm);
    await expect(searchPage.productCards.first()).toBeVisible();
    await searchPage.openProduct(0);
    await cartPage.addCurrentProduct();
    await cartPage.open();
    await checkoutPage.goToAddressStep();
  });

  test('cannot continue with a missing address field', async ({ checkoutPage }) => {
    await checkoutPage.street.fill('');
    await expect(checkoutPage.proceedFromAddress).toBeDisabled();
  });

  test('places an order with a credit card', async ({ checkoutPage }) => {
    await checkoutPage.fillAddress(address);
    await checkoutPage.goToPaymentStep();
    await checkoutPage.fillCard(card.valid);
    await checkoutPage.confirmPayment();

    await expect(checkoutPage.orderConfirmation).toContainText(/thanks for your order/i);
    await expect(checkoutPage.orderConfirmation).toContainText(/invoice number/i);
  });

  test('places an order with cash on delivery', async ({ checkoutPage }) => {
    await checkoutPage.fillAddress(address);
    await checkoutPage.goToPaymentStep();
    await checkoutPage.paymentMethod.selectOption('cash-on-delivery');
    await checkoutPage.confirmPayment();

    await expect(checkoutPage.orderConfirmation).toContainText(/invoice number/i);
  });

  test('cannot pay with an invalid card number', async ({ checkoutPage }) => {
    await checkoutPage.fillAddress(address);
    await checkoutPage.goToPaymentStep();
    await checkoutPage.fillCard({ ...card.valid, number: card.invalidNumber });
    await expect(checkoutPage.finishButton).toBeDisabled();
  });

  test('empties the cart after a successful order', async ({ checkoutPage }) => {
    await checkoutPage.fillAddress(address);
    await checkoutPage.goToPaymentStep();
    await checkoutPage.fillCard(card.valid);
    await checkoutPage.confirmPayment();
    await expect(checkoutPage.orderConfirmation).toBeVisible();

    await expect(checkoutPage.cartBadge).toBeHidden();
  });
});
