const { test, expect } = require('../fixtures');
const { products } = require('../test-data/data');

const isAscending = (a) => a.every((v, i) => i === 0 || a[i - 1] <= v);
const isDescending = (a) => a.every((v, i) => i === 0 || a[i - 1] >= v);
const byName = (a, b) => a.localeCompare(b);

test.describe('Product search', () => {
  test('returns matching products', async ({ searchPage }) => {
    await searchPage.search(products.searchTerm);
    await expect(searchPage.productCards.first()).toBeVisible();
    await expect(searchPage.searchCaption).toBeVisible();
    for (const name of await searchPage.names()) {
      expect(name.toLowerCase()).toContain(products.searchTerm);
    }
  });

  test('shows a message when nothing matches', async ({ searchPage }) => {
    await searchPage.search(products.unknownTerm);
    await expect(searchPage.noResults).toBeVisible();
    await expect(searchPage.productCards).toHaveCount(0);
  });

  test('reset clears the search', async ({ searchPage }) => {
    await searchPage.search(products.unknownTerm);
    await expect(searchPage.noResults).toBeVisible();
    await searchPage.searchReset.click();
    await expect(searchPage.productCards.first()).toBeVisible();
  });
});

test.describe('Filters', () => {
  test('filters by brand', async ({ searchPage, page }) => {
    await searchPage.goto('/');
    await expect(searchPage.productCards.first()).toBeVisible();

    const request = page.waitForResponse((r) => r.url().includes('by_brand'));
    await searchPage.brandCheckboxes.first().check();
    expect((await request).ok()).toBeTruthy();
    await expect(searchPage.productCards.first()).toBeVisible();
  });

  test('filters by category', async ({ searchPage, page }) => {
    await searchPage.goto('/');
    await expect(searchPage.productCards.first()).toBeVisible();

    const request = page.waitForResponse((r) => r.url().includes('by_category'));
    await searchPage.categoryCheckboxes.first().check();
    expect((await request).ok()).toBeTruthy();
    await expect(searchPage.productCards.first()).toBeVisible();
  });
});

test.describe('Sorting', () => {
  test('name A to Z', async ({ searchPage }) => {
    await searchPage.goto('/');
    await expect(searchPage.productCards.first()).toBeVisible();
    await searchPage.sortBy('name,asc');
    await expect
      .poll(async () => {
        const n = await searchPage.names();
        return JSON.stringify(n) === JSON.stringify([...n].sort(byName));
      })
      .toBe(true);
  });

  test('name Z to A', async ({ searchPage }) => {
    await searchPage.goto('/');
    await expect(searchPage.productCards.first()).toBeVisible();
    await searchPage.sortBy('name,desc');
    await expect
      .poll(async () => {
        const n = await searchPage.names();
        return JSON.stringify(n) === JSON.stringify([...n].sort(byName).reverse());
      })
      .toBe(true);
  });

  test('price low to high', async ({ searchPage }) => {
    await searchPage.goto('/');
    await expect(searchPage.productCards.first()).toBeVisible();
    await searchPage.sortBy('price,asc');
    await expect.poll(async () => isAscending(await searchPage.prices())).toBe(true);
  });

  test('price high to low', async ({ searchPage }) => {
    await searchPage.goto('/');
    await expect(searchPage.productCards.first()).toBeVisible();
    await searchPage.sortBy('price,desc');
    await expect.poll(async () => isDescending(await searchPage.prices())).toBe(true);
  });
});

test.describe('Pagination', () => {
  test('moves to the next and previous page', async ({ searchPage }) => {
    await searchPage.goto('/');
    await expect(searchPage.productCards.first()).toBeVisible();
    await expect(searchPage.activePage).toHaveText('1');
    const firstOnPage1 = (await searchPage.names())[0];

    await searchPage.nextPage.click();
    await expect(searchPage.activePage).toHaveText('2');
    await expect.poll(async () => (await searchPage.names())[0]).not.toBe(firstOnPage1);

    await searchPage.prevPage.click();
    await expect(searchPage.activePage).toHaveText('1');
    await expect.poll(async () => (await searchPage.names())[0]).toBe(firstOnPage1);
  });
});
