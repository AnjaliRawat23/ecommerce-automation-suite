const { test, expect } = require('../fixtures');
const { newUser } = require('../test-data/data');

test.describe('Sign up', () => {
  test('registers a new user', async ({ authPage, page }) => {
    await authPage.signUp(newUser());
    // after registering the site sends the user to the login page
    await expect(page).toHaveURL(/auth\/login/);
  });

  test('rejects an already registered email', async ({ authPage, account }) => {
    await authPage.signUp({ ...newUser(), email: account.email });
    await expect(authPage.registerError).toContainText(/already exists/i);
  });

  test('rejects a weak password', async ({ authPage }) => {
    await authPage.signUp({ ...newUser(), password: '123' });
    await expect(authPage.passwordError).toBeVisible();
  });

  test('shows validation errors for an empty form', async ({ authPage }) => {
    await authPage.gotoRegister();
    await authPage.registerSubmit.click();
    await expect(authPage.firstNameError).toBeVisible();
  });
});

test.describe('Login / logout', () => {
  test('logs in with valid credentials', async ({ authPage, page, account }) => {
    await authPage.login(account.email, account.password);
    await expect(page).toHaveURL(/account/);
    await expect(authPage.navMenu).toContainText(account.fullName);
  });

  test('shows an error for a wrong password', async ({ authPage, page }) => {
    // Use a throwaway user: repeated failed logins lock an account,
    // and we do not want to lock the user the other tests rely on.
    const user = newUser();
    await authPage.signUp(user);
    await expect(page).toHaveURL(/auth\/login/);

    await authPage.login(user.email, 'WrongPass!1');
    await expect(authPage.loginError).toContainText(/invalid/i);
  });

  test('shows validation for empty fields', async ({ authPage }) => {
    await authPage.gotoLogin();
    await authPage.loginSubmit.click();
    await expect(authPage.emailError).toBeVisible();
    await expect(authPage.passwordError).toBeVisible();
  });

  test('logs out and blocks account pages', async ({ authPage, page, account }) => {
    await authPage.login(account.email, account.password);
    await expect(authPage.navMenu).toBeVisible();

    await authPage.logout();
    await expect(page).toHaveURL(/auth\/login/);
    await expect(authPage.navSignIn).toBeVisible();

    await page.goto('/account');
    await expect(page).toHaveURL(/auth\/login/);
  });
});

test.describe('Password reset', () => {
  test('accepts a registered email', async ({ authPage, account }) => {
    await authPage.requestPasswordReset(account.email);
    await expect(authPage.successAlert).toBeVisible();
  });

  test('validates the email format', async ({ authPage }) => {
    await authPage.requestPasswordReset('not-an-email');
    await expect(authPage.emailError).toBeVisible();
  });
});

test.describe('Social login', () => {
  // Only checks that the Google button starts the provider flow.
  // It never signs in to a real Google account.
  test('Google button starts the Google sign-in flow', async ({ authPage, page }) => {
    await authPage.gotoLogin();
    await expect(authPage.googleButton).toBeVisible();

    const popupPromise = page.waitForEvent('popup', { timeout: 10_000 }).catch(() => null);
    await authPage.googleButton.click();
    const popup = await popupPromise;
    const target = popup || page;
    await expect.poll(() => target.url(), { timeout: 15_000 }).toMatch(/google/i);
  });
});
