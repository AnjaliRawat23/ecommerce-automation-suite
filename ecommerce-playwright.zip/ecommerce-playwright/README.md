# E-Commerce Website Test Automation

Test framework for an e-commerce website built with **Playwright**, **JavaScript** and the **Page Object Model**.

The tests run against the public practice shop **[practicesoftwaretesting.com](https://practicesoftwaretesting.com)** (the Toolshop demo by Testsmith). It is a demo site made for test automation practice, so it is safe to sign up and place orders there.

## What is covered

| Area | Tests |
| --- | --- |
| Authentication | Sign up (valid, duplicate email, weak password, empty form), login (valid, wrong password, empty fields), logout, password reset, Google login button |
| Search | Keyword search, no results, brand and category filters, sorting (name and price), pagination |
| Cart | Add / remove items, change quantity, cart kept after login |
| Checkout | Address validation, credit card order, cash on delivery order, invalid card, order confirmation, cart emptied |
| Account | Profile update, order history (places an order, then checks the invoice list), wishlist (favorites) |

## Project structure

```
pages/         Page objects (BasePage, AuthPage, SearchPage, CartPage, CheckoutPage, AccountPage)
fixtures/      Custom Playwright fixtures that give each test its page objects
test-data/     Shared test data (users, address, card, search terms)
tests/         Spec files, one per feature area
```

## Setup

```bash
npm install
npx playwright install
```

No `.env` file is needed: the default points at the demo site. To change it, copy `.env.example` to `.env` (`copy .env.example .env` on Windows, `cp .env.example .env` on Mac/Linux) and edit `BASE_URL`.

## Running

```bash
npm test                              # all tests, Chromium and Firefox
npx playwright test --project=chromium
npm run test:headed                   # watch the browser
npm run test:auth                     # one area (also: search, cart, checkout, account)
npm run report                        # open the HTML report
```

## How the locators work

The site marks its elements with a `data-test` attribute. `playwright.config.js` sets
`testIdAttribute: 'data-test'`, so `page.getByTestId('login-submit')` finds
`<button data-test="login-submit">`. All locators live in `pages/`, so if the site changes, you fix one file and the tests stay the same.

## Notes

- The tests do **not** use the site's shared demo customer. That account is public, so other visitors lock it or change its password, which breaks every test that logs in. Instead each worker registers its own new customer (the `account` fixture in `fixtures/index.js`) and all tests use that.
- The wrong-password test uses a separate throwaway user, because repeated failed logins lock an account.
- The first test in each worker is slower because it registers the user first.
- The site is public and shared, so tests run with 2 workers and 1 retry to avoid rate limits and one-off slowness.
- The Google login test only checks that the button starts the Google flow. It does not sign in to a real account.
- The desktop layout is tested. The mobile layout hides the menu behind a hamburger button, so it would need its own locators.
