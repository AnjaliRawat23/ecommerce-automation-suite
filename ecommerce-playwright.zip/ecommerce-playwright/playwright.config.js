// @ts-check
const { defineConfig, devices } = require('@playwright/test');
require('dotenv').config();

module.exports = defineConfig({
  testDir: './tests',
  // The public demo site can be slow (a login alone can take 20-30s), so be generous
  timeout: 120_000,
  expect: { timeout: 20_000 },
  fullyParallel: true,
  retries: process.env.CI ? 2 : 1,
  // The demo site is shared and public, so keep parallelism gentle
  workers: process.env.CI ? 2 : 2,
  reporter: [['html', { open: 'never' }], ['list']],
  use: {
    baseURL: process.env.BASE_URL || 'https://practicesoftwaretesting.com',
    actionTimeout: 30_000,
    navigationTimeout: 60_000,
    // The site marks its elements with data-test, so getByTestId() uses that attribute
    testIdAttribute: 'data-test',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
  ],
});
