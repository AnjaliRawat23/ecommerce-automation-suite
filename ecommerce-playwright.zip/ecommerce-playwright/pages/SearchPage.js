const { BasePage } = require('./BasePage');

class SearchPage extends BasePage {
  constructor(page) {
    super(page);
    this.searchInput = page.getByTestId('search-query');
    this.searchSubmit = page.getByTestId('search-submit');
    this.searchReset = page.getByTestId('search-reset');
    this.searchCaption = page.getByTestId('search-caption');
    this.noResults = page.getByTestId('no-results');

    // Each product card is a link with data-test="product-<id>"
    this.productCards = page.locator('a[data-test^="product-"]');
    this.productNames = page.getByTestId('product-name');
    this.productPrices = page.getByTestId('product-price');

    this.sortSelect = page.getByTestId('sort');
    this.categoryCheckboxes = page.locator('input[data-test^="category-"]');
    this.brandCheckboxes = page.locator('input[data-test^="brand-"]');

    this.nextPage = page.getByTestId('pagination-next');
    this.prevPage = page.getByTestId('pagination-prev');
    this.activePage = page.locator('li.page-item.active');
  }

  async search(term) {
    await this.goto('/');
    await this.searchInput.fill(term);
    await this.searchSubmit.click();
  }

  /** Sort values: name,asc | name,desc | price,asc | price,desc */
  async sortBy(value) {
    await this.sortSelect.selectOption(value);
  }

  async names() {
    return (await this.productNames.allTextContents()).map((t) => t.trim());
  }

  async prices() {
    const texts = await this.productPrices.allTextContents();
    return texts.map((t) => parseFloat(t.replace(/[^0-9.]/g, '')));
  }

  async openProduct(index = 0) {
    await this.productCards.nth(index).click();
  }
}

module.exports = { SearchPage };
