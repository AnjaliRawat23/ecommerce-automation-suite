const { BasePage } = require('./BasePage');

class CheckoutPage extends BasePage {
  constructor(page) {
    super(page);
    // Step 1 (cart) -> step 2 (sign in) -> step 3 (address) -> step 4 (payment)
    this.proceedFromCart = page.getByTestId('proceed-1');
    this.proceedFromSignIn = page.getByTestId('proceed-2'); // shown when already logged in
    this.proceedFromAddress = page.getByTestId('proceed-3');

    // Address
    this.postalCode = page.getByTestId('postal_code');
    this.houseNumber = page.getByTestId('house_number');
    this.street = page.getByTestId('street');
    this.city = page.getByTestId('city');
    this.state = page.getByTestId('state');

    // Payment
    this.paymentMethod = page.getByTestId('payment-method');
    this.cardNumber = page.getByTestId('credit_card_number');
    this.cardExpiry = page.getByTestId('expiration_date');
    this.cardCvv = page.getByTestId('cvv');
    this.cardHolder = page.getByTestId('card_holder_name');
    this.finishButton = page.getByTestId('finish');
    this.paymentSuccess = page.getByTestId('payment-success-message');
    this.orderConfirmation = page.locator('#order-confirmation');
  }

  /** From the cart page to the address step (logged-in user). */
  async goToAddressStep() {
    await this.proceedFromCart.click();
    await this.proceedFromSignIn.click();
  }

  async fillAddress(a) {
    await this.postalCode.fill(a.postalCode);
    await this.houseNumber.fill(a.houseNumber);
    await this.street.fill(a.street);
    await this.city.fill(a.city);
    await this.state.fill(a.state);
  }

  async goToPaymentStep() {
    await this.proceedFromAddress.click();
    await this.paymentMethod.waitFor({ state: 'visible' });
  }

  async fillCard(c) {
    await this.paymentMethod.selectOption('credit-card');
    await this.cardNumber.fill(c.number);
    await this.cardExpiry.fill(c.expiry);
    await this.cardCvv.fill(c.cvv);
    await this.cardHolder.fill(c.name);
  }

  /** Confirm the payment. The site shows a success message first, then a second confirm shows the order. */
  async confirmPayment() {
    await this.finishButton.click();
    await this.paymentSuccess.waitFor({ state: 'visible' });
    await this.finishButton.click({ timeout: 5_000 }).catch(() => {});
  }
}

module.exports = { CheckoutPage };
