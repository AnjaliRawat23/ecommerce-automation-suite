const { BasePage } = require('./BasePage');

class CartPage extends BasePage {
  constructor(page) {
    super(page);
    // Product detail page
    this.addToCartButton = page.getByTestId('add-to-cart');
    this.productTitle = page.getByTestId('product-name');
    this.unitPrice = page.getByTestId('unit-price');

    // Cart (first step of /checkout)
    this.rows = page.locator('tr').filter({ has: page.getByTestId('product-title') });
    this.cartTotal = page.getByTestId('cart-total');
    this.proceedButton = page.getByTestId('proceed-1');
  }

  async open() { await this.goto('/checkout'); }

  /** Click "Add to cart" on the product page that is open and wait for the header badge. */
  async addCurrentProduct() {
    await this.addToCartButton.click();
    await this.cartBadge.waitFor({ state: 'visible' });
  }

  row(index = 0) { return this.rows.nth(index); }

  async removeRow(index = 0) {
    await this.row(index).locator('a.btn.btn-danger').click();
  }

  async setQuantity(index, qty) {
    const input = this.row(index).getByTestId('product-quantity');
    await input.fill(String(qty));
    await input.press('Tab'); // the cart updates when the field loses focus
  }

  async quantityOf(index = 0) {
    return parseInt(await this.row(index).getByTestId('product-quantity').inputValue(), 10);
  }

  async money(locator) {
    const text = (await locator.first().textContent()) || '0';
    return parseFloat(text.replace(/[^0-9.]/g, ''));
  }

  unitPriceOf(index = 0) { return this.money(this.row(index).getByTestId('product-price')); }
  lineTotalOf(index = 0) { return this.money(this.row(index).getByTestId('line-price')); }
  total() { return this.money(this.cartTotal); }
}

module.exports = { CartPage };
