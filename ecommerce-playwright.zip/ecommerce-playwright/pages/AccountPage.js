const { BasePage } = require('./BasePage');

class AccountPage extends BasePage {
  constructor(page) {
    super(page);
    this.pageTitle = page.getByTestId('page-title');

    // Profile
    this.firstName = page.getByTestId('first-name');
    this.lastName = page.getByTestId('last-name');
    this.phone = page.getByTestId('phone');
    this.updateProfileButton = page.getByTestId('update-profile-submit');
    this.successAlert = page.locator('.alert-success');

    // Invoices (order history)
    this.invoiceRows = page.locator('table tbody tr');

    // Favorites (the wishlist)
    this.addToFavorites = page.getByTestId('add-to-favorites');
    this.favoriteCards = page.locator('[data-test^="favorite-"]');
    this.deleteFavoriteButtons = page.getByTestId('delete');
  }

  async openProfile() { await this.goto('/account/profile'); }
  async openInvoices() { await this.goto('/account/invoices'); }
  async openFavorites() { await this.goto('/account/favorites'); }

  async updatePhone(phone) {
    await this.openProfile();
    await this.phone.fill(phone);
    await this.updateProfileButton.click();
  }

  /** Remove every favorite so tests start from an empty list. */
  async clearFavorites() {
    await this.openFavorites();
    await this.pageTitle.waitFor({ state: 'visible' });
    while ((await this.deleteFavoriteButtons.count()) > 0) {
      await this.deleteFavoriteButtons.first().click();
      await this.page.waitForTimeout(500);
    }
  }
}

module.exports = { AccountPage };
