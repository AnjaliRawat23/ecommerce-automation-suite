const { BasePage } = require('./BasePage');

class AuthPage extends BasePage {
  constructor(page) {
    super(page);
    // Shared fields
    this.email = page.getByTestId('email');
    // The password field sits inside a custom component, so it is found by id
    this.password = page.locator('input#password, #password input').first();

    // Login
    this.loginSubmit = page.getByTestId('login-submit');
    this.loginError = page.getByTestId('login-error');
    this.emailError = page.getByTestId('email-error');
    this.passwordError = page.getByTestId('password-error');
    this.forgotPasswordLink = page.getByTestId('forgot-password-link');
    this.registerLink = page.getByTestId('register-link');
    this.googleButton = page.getByRole('button', { name: /sign in with google/i });

    // Register
    this.firstName = page.getByTestId('first-name');
    this.lastName = page.getByTestId('last-name');
    this.dob = page.getByTestId('dob');
    this.country = page.getByTestId('country');
    this.postalCode = page.getByTestId('postal_code');
    this.houseNumber = page.getByTestId('house_number');
    this.street = page.getByTestId('street');
    this.city = page.getByTestId('city');
    this.state = page.getByTestId('state');
    this.phone = page.getByTestId('phone');
    this.registerSubmit = page.getByTestId('register-submit');
    this.registerError = page.getByTestId('register-error');
    this.firstNameError = page.getByTestId('first-name-error');

    // Forgot password
    this.forgotSubmit = page.getByTestId('forgot-password-submit');
    this.successAlert = page.locator('.alert-success');
    this.errorAlert = page.locator('.alert-danger');
  }

  async gotoLogin() { await this.goto('/auth/login'); }
  async gotoRegister() { await this.goto('/auth/register'); }
  async gotoForgotPassword() { await this.goto('/auth/forgot-password'); }

  async login(email, password) {
    await this.gotoLogin();
    await this.email.fill(email);
    await this.password.fill(password);
    await this.loginSubmit.click();
  }

  async fillRegistration(u) {
    await this.firstName.fill(u.firstName);
    await this.lastName.fill(u.lastName);
    await this.dob.fill(u.dob);
    await this.country.selectOption(u.country);
    await this.postalCode.fill(u.postalCode);
    await this.houseNumber.fill(u.houseNumber);
    await this.street.fill(u.street);
    await this.city.fill(u.city);
    await this.state.fill(u.state);
    await this.phone.fill(u.phone);
    await this.email.fill(u.email);
    await this.password.fill(u.password);
  }

  async signUp(user) {
    await this.gotoRegister();
    await this.fillRegistration(user);
    await this.registerSubmit.click();
  }

  async requestPasswordReset(email) {
    await this.gotoForgotPassword();
    await this.email.fill(email);
    await this.forgotSubmit.click();
  }
}

module.exports = { AuthPage };
