class BasePage {
  /** @param {import('@playwright/test').Page} page */
  constructor(page) {
    this.page = page;
    // Header (the site uses data-test attributes; testIdAttribute is set in the config)
    this.navSignIn = page.getByTestId('nav-sign-in');
    this.navMenu = page.getByTestId('nav-menu'); // only visible when logged in
    this.navSignOut = page.getByTestId('nav-sign-out');
    this.navCart = page.getByTestId('nav-cart'); // only visible when the cart has items
    this.cartBadge = page.getByTestId('cart-quantity');
  }

  async goto(path = '/') {
    await this.page.goto(path);
  }

  async logout() {
    await this.navMenu.click();
    await this.navSignOut.click();
  }

  async cartCount() {
    if (!(await this.cartBadge.isVisible())) return 0;
    return parseInt(((await this.cartBadge.textContent()) || '0').trim(), 10) || 0;
  }
}

module.exports = { BasePage };
